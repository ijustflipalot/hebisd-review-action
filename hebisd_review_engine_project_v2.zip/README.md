# HEB ISD Review Engine Starter

This repository is a starter rules-driven engine for criminal history review workflows.

## What it does

- loads offense rules and job rules from an Excel workbook
- classifies each offense
- generates a structured decision-tree path map
- validates the path map before rendering
- stamps PDFs with check marks / text using PyMuPDF
- can render a CRC DOCX template with simple placeholders

## Files

- `main.py` — CLI entry point
- `server.py` — FastAPI service
- `hebisd_review_engine.py` — orchestration layer
- `engine/` — classifier, decision tree, validation, rendering helpers
- `rules/HEB_ISD_Rules_Workbook.xlsx` — starter rules workbook
- `templates/` — placeholder template folder

## Install

```bash
pip install -r requirements.txt
```

## Run the CLI

```bash
python main.py analyze --case sample_case.json --rules rules/HEB_ISD_Rules_Workbook.xlsx --out output
```

## Run the API

```bash
uvicorn server:app --reload
```

## Important

The PDF renderer uses placeholder checkbox coordinates in `engine/pdf_renderer.py`. Replace those with the actual template coordinates before production use.
