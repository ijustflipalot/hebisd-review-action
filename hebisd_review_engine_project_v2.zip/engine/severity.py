from __future__ import annotations

from typing import Dict

_SEVERITY_ORDER = {
    "lowest": 1,
    "low": 2,
    "moderate": 3,
    "medium": 3,
    "high": 4,
    "highest": 5,
    "unknown": 0,
}


def severity_rank(label: str) -> int:
    return _SEVERITY_ORDER.get((label or "").strip().lower(), 0)


def is_high_or_above(label: str) -> bool:
    return severity_rank(label) >= 4


def normalize_classification(classification: str) -> str:
    return (classification or "").strip().title()
