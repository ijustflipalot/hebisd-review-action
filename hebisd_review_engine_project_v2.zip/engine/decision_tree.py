from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List

from .classifier import classify_offense, years_between, offense_category_from_text
from .models import ApplicantCase, CrimeEvent, PathStep, RulesCatalog
from .severity import severity_rank


def _job_related(position: str, offense_category: str, rules: RulesCatalog) -> bool:
    job = rules.job_rules.get((position or "").lower())
    if job:
        if offense_category in {c.lower().strip() for c in job.related_categories}:
            return True
        if offense_category == "other":
            return job.default_related
        return job.default_related
    # Conservative default for school bus driver and similar student-facing roles.
    if (position or "").strip().lower() == "bus driver":
        return offense_category in {"assault", "intoxication", "property"}
    return offense_category in {"assault", "property", "drug", "intoxication"}


def _terminal(label: str, committee: bool = False) -> str:
    return "CRC_REVIEW" if committee else label


def build_path_map(event: CrimeEvent, position: str, rules: RulesCatalog, application_date: str | None = None) -> Dict[str, Any]:
    rule = classify_offense(event.offense_text, rules)
    offense_category = offense_category_from_text(event.offense_text)
    felony = "felony" in (rule.classification or "").lower() or rule.classification.lower().startswith(("f1", "f2", "f3", "fs"))
    class_a_b = "class a" in rule.classification.lower() or "class b" in rule.classification.lower()
    class_c = "class c" in rule.classification.lower()
    mt = bool(rule.moral_turpitude)
    years = years_between(event.date, application_date) if event.date else None
    related = _job_related(position, offense_category, rules)
    q_path: List[PathStep] = []

    # Q1 is always yes under the custom workflow described in the chat.
    q_path.append(PathStep(question=1, answer="Yes", reason="Custom workflow / treated as report received."))

    if rule.prohibited:
        q_path.extend([
            PathStep(question=3, answer="Yes", reason="Prohibited offense flag set."),
            PathStep(question=4, answer="Yes" if event.treat_as_conviction else "No", reason="Disposition handling."),
        ])
        terminal = _terminal("INELIGIBLE", committee=False)
        return {
            "offense_text": event.offense_text,
            "date": event.date,
            "classification": rule.classification,
            "statute": rule.statute,
            "severity": rule.severity,
            "category": offense_category,
            "related_to_position": related,
            "treat_as_conviction": event.treat_as_conviction,
            "path": [asdict(step) for step in q_path],
            "terminal": terminal,
            "review_required": True,
            "notes": rule.notes,
        }

    q_path.append(PathStep(question=3, answer="No", reason="No prohibited offense flag."))

    if felony:
        q_path.append(PathStep(question=5, answer="Yes", reason="Felony classification."))
        if years is not None and years >= 10:
            q_path.append(PathStep(question=6, answer="Yes", reason="Offense is 10+ years old."))
            q_path.append(PathStep(question=7, answer="Yes" if related else "No", reason="Job relation check."))
            if related:
                q_path.append(PathStep(question=8, answer="Yes" if event.treat_as_conviction else "No", reason="Disposition check."))
                terminal = _terminal("CRC_REVIEW", committee=True)
            else:
                terminal = _terminal("ELIGIBLE", committee=False)
                return {
                    "offense_text": event.offense_text,
                    "date": event.date,
                    "classification": rule.classification,
                    "statute": rule.statute,
                    "severity": rule.severity,
                    "category": offense_category,
                    "related_to_position": related,
                    "treat_as_conviction": event.treat_as_conviction,
                    "path": [asdict(step) for step in q_path],
                    "terminal": terminal,
                    "review_required": False,
                    "notes": rule.notes,
                }
        else:
            q_path.append(PathStep(question=6, answer="No" if years is not None else "Unknown", reason="Less than 10 years old or date missing."))
            q_path.append(PathStep(question=8, answer="Yes" if event.treat_as_conviction else "No", reason="Felony conviction/adjudication check."))
            terminal = _terminal("CRC_REVIEW", committee=True)

        return {
            "offense_text": event.offense_text,
            "date": event.date,
            "classification": rule.classification,
            "statute": rule.statute,
            "severity": rule.severity,
            "category": offense_category,
            "related_to_position": related,
            "treat_as_conviction": event.treat_as_conviction,
            "path": [asdict(step) for step in q_path],
            "terminal": terminal,
            "review_required": True,
            "notes": rule.notes,
        }

    # Misdemeanor logic
    q_path.append(PathStep(question=5, answer="No", reason="Not a felony."))

    if class_a_b:
        q_path.append(PathStep(question=9, answer="Yes", reason="Class A or B misdemeanor."))
        q_path.append(PathStep(question=15, answer="Yes" if related else "No", reason="Job relation check."))
        if related:
            q_path.append(PathStep(question=16, answer="Yes" if (years is not None and years <= 5) else "No", reason="Five-year window check."))
            if years is not None and years <= 5:
                q_path.append(PathStep(question=17, answer="Yes" if event.treat_as_conviction else "No", reason="Conviction/adjudication check."))
                terminal = _terminal("CRC_REVIEW", committee=True)
            else:
                terminal = _terminal("ELIGIBLE", committee=False)
        else:
            terminal = _terminal("ELIGIBLE", committee=False)

        return {
            "offense_text": event.offense_text,
            "date": event.date,
            "classification": rule.classification,
            "statute": rule.statute,
            "severity": rule.severity,
            "category": offense_category,
            "related_to_position": related,
            "treat_as_conviction": event.treat_as_conviction,
            "path": [asdict(step) for step in q_path],
            "terminal": terminal,
            "review_required": terminal == "CRC_REVIEW",
            "notes": rule.notes,
        }

    if class_c:
        q_path.append(PathStep(question=9, answer="No", reason="Not class A/B."))
        q_path.append(PathStep(question=10, answer="Yes" if mt else "No", reason="Class C moral turpitude check."))
        if mt:
            q_path.append(PathStep(question=11, answer="Yes" if event.treat_as_conviction else "No", reason="Conviction/adjudication check."))
            q_path.append(PathStep(question=13, answer="Yes" if (years is not None and years <= 5) else "No", reason="Five-year window check."))
            q_path.append(PathStep(question=14, answer="Yes" if event.treat_as_conviction else "No", reason="Conviction/adjudication check."))
            terminal = _terminal("CRC_REVIEW", committee=True)
        else:
            q_path.append(PathStep(question=12, answer="Yes" if related else "No", reason="Job relation check."))
            if related and years is not None and years <= 5:
                q_path.append(PathStep(question=13, answer="Yes", reason="Five-year window check."))
                q_path.append(PathStep(question=14, answer="Yes" if event.treat_as_conviction else "No", reason="Conviction/adjudication check."))
                terminal = _terminal("CRC_REVIEW", committee=True)
            else:
                terminal = _terminal("ELIGIBLE", committee=False)

        return {
            "offense_text": event.offense_text,
            "date": event.date,
            "classification": rule.classification,
            "statute": rule.statute,
            "severity": rule.severity,
            "category": offense_category,
            "related_to_position": related,
            "treat_as_conviction": event.treat_as_conviction,
            "path": [asdict(step) for step in q_path],
            "terminal": terminal,
            "review_required": terminal == "CRC_REVIEW",
            "notes": rule.notes,
        }

    # Unknown / uncategorized misdemeanor
    q_path.append(PathStep(question=9, answer="No", reason="Misdemeanor path not fully classified."))
    q_path.append(PathStep(question=12, answer="Yes" if related else "No", reason="Fallback job relation check."))
    terminal = _terminal("CRC_REVIEW" if related else "ELIGIBLE", committee=related)
    return {
        "offense_text": event.offense_text,
        "date": event.date,
        "classification": rule.classification,
        "statute": rule.statute,
        "severity": rule.severity,
        "category": offense_category,
        "related_to_position": related,
        "treat_as_conviction": event.treat_as_conviction,
        "path": [asdict(step) for step in q_path],
        "terminal": terminal,
        "review_required": terminal == "CRC_REVIEW",
        "notes": rule.notes,
    }


def build_case_paths(case: ApplicantCase, rules: RulesCatalog) -> Dict[str, Any]:
    offense_results: List[Dict[str, Any]] = []
    for event in case.events:
        offense_results.append(build_path_map(event, case.position, rules, application_date=case.application_date))

    crc_required = any(item["terminal"] == "CRC_REVIEW" for item in offense_results) or len(offense_results) > 1
    if len(offense_results) > 1:
        # Multiple offenses are always flagged for review in this starter engine
        # so the human reviewer can confirm cumulative-risk handling.
        crc_required = True

    return {
        "applicant_name": case.applicant_name,
        "position": case.position,
        "case_meta": {
            "arrest_date": case.arrest_date,
            "application_date": case.application_date,
            **case.extra,
        },
        "offenses": offense_results,
        "crc_required": crc_required,
    }
