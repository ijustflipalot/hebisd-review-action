from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from .models import JobRule, OffenseRule, RulesCatalog


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    text = str(value).strip().lower()
    return text in {"1", "true", "t", "yes", "y", "x"}


def _split_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    text = str(value).strip()
    if not text:
        return []
    return [part.strip() for part in text.split(",") if part.strip()]


def load_rules_workbook(path: str | Path) -> RulesCatalog:
    workbook_path = Path(path)
    if not workbook_path.exists():
        raise FileNotFoundError(f"Rules workbook not found: {workbook_path}")

    wb = load_workbook(workbook_path, data_only=True)

    offense_rules: list[OffenseRule] = []
    job_rules: dict[str, JobRule] = {}
    settings: dict[str, Any] = {}

    if "Offenses" in wb.sheetnames:
        ws = wb["Offenses"]
        headers = [str(c.value).strip() if c.value is not None else "" for c in ws[1]]
        header_map = {name.lower(): idx for idx, name in enumerate(headers)}
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row or not any(v is not None and str(v).strip() for v in row):
                continue
            offense_rules.append(
                OffenseRule(
                    match_text=str(row[header_map.get("match_text", 0)] or "").strip(),
                    statute=str(row[header_map.get("statute", 1)] or "").strip(),
                    classification=str(row[header_map.get("classification", 2)] or "Unknown").strip(),
                    severity=str(row[header_map.get("severity", 3)] or "Unknown").strip(),
                    prohibited=_as_bool(row[header_map.get("prohibited", 4)] if "prohibited" in header_map else False),
                    moral_turpitude=_as_bool(row[header_map.get("moral_turpitude", 5)] if "moral_turpitude" in header_map else False),
                    relation_hint=str(row[header_map.get("relation_hint", 6)] or "").strip(),
                    default_terminal=str(row[header_map.get("default_terminal", 7)] or "").strip(),
                    notes=str(row[header_map.get("notes", 8)] or "").strip(),
                )
            )

    if "Jobs" in wb.sheetnames:
        ws = wb["Jobs"]
        headers = [str(c.value).strip() if c.value is not None else "" for c in ws[1]]
        header_map = {name.lower(): idx for idx, name in enumerate(headers)}
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row or not any(v is not None and str(v).strip() for v in row):
                continue
            position = str(row[header_map.get("position", 0)] or "").strip()
            job_rules[position.lower()] = JobRule(
                position=position,
                related_categories=_split_list(row[header_map.get("related_categories", 1)] if "related_categories" in header_map else []),
                default_related=_as_bool(row[header_map.get("default_related", 2)] if "default_related" in header_map else False),
                notes=str(row[header_map.get("notes", 3)] or "").strip(),
            )

    if "Settings" in wb.sheetnames:
        ws = wb["Settings"]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row or row[0] is None:
                continue
            key = str(row[0]).strip()
            value = row[1]
            settings[key] = value

    # Sensible defaults
    settings.setdefault("assume_q1_yes", True)
    settings.setdefault("treat_arrest_as_conviction", True)
    settings.setdefault("treat_deferred_as_conviction", True)
    settings.setdefault("default_time_unit", "years")
    settings.setdefault("bus_driver_default_related", True)
    settings.setdefault("high_risk_terminal", "CRC_REVIEW")

    return RulesCatalog(offense_rules=offense_rules, job_rules=job_rules, settings=settings)
