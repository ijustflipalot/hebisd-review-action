from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class OffenseRule:
    match_text: str
    statute: str = ""
    classification: str = "Unknown"
    severity: str = "Unknown"
    prohibited: bool = False
    moral_turpitude: bool = False
    relation_hint: str = ""
    default_terminal: str = ""
    notes: str = ""


@dataclass
class JobRule:
    position: str
    related_categories: List[str] = field(default_factory=list)
    default_related: bool = False
    notes: str = ""


@dataclass
class RulesCatalog:
    offense_rules: List[OffenseRule] = field(default_factory=list)
    job_rules: Dict[str, JobRule] = field(default_factory=dict)
    settings: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "offense_rules": [asdict(r) for r in self.offense_rules],
            "job_rules": {k: asdict(v) for k, v in self.job_rules.items()},
            "settings": self.settings,
        }


@dataclass
class CrimeEvent:
    date: str
    offense_text: str
    disposition: str = "arrest"
    treat_as_conviction: bool = True
    notes: str = ""


@dataclass
class ApplicantCase:
    applicant_name: str
    position: str
    arrest_date: Optional[str] = None
    application_date: Optional[str] = None
    events: List[CrimeEvent] = field(default_factory=list)
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PathStep:
    question: int
    answer: str
    reason: str = ""
    next_question: Optional[int] = None


@dataclass
class ValidationResult:
    passed: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


@dataclass
class CaseResult:
    applicant_name: str
    position: str
    case_meta: Dict[str, Any]
    offenses: List[Dict[str, Any]]
    crc_required: bool
    validation: Dict[str, Any]
    render_ready: Dict[str, Any]
