from __future__ import annotations

import re
from datetime import datetime
from typing import Optional, Tuple

from .models import OffenseRule, RulesCatalog


def _norm(text: str) -> str:
    text = (text or "").lower()
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def classify_offense(offense_text: str, rules: RulesCatalog) -> OffenseRule:
    norm = _norm(offense_text)
    best: OffenseRule | None = None
    best_score = -1

    for rule in rules.offense_rules:
        needle = _norm(rule.match_text)
        if not needle:
            continue
        if needle in norm:
            score = len(needle)
            if score > best_score:
                best = rule
                best_score = score

    if best is not None:
        return best

    return OffenseRule(
        match_text=offense_text,
        statute="",
        classification="Unknown",
        severity="Unknown",
        prohibited=False,
        moral_turpitude=False,
        relation_hint="",
        default_terminal="CRC_REVIEW",
        notes="No direct offense rule match.",
    )


def parse_yearish(value: str | None) -> Optional[datetime]:
    if not value:
        return None
    text = str(value).strip()
    if not text:
        return None
    # Accept YYYY, YYYY-MM-DD, MM/DD/YYYY, or other obvious date strings.
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%Y/%m/%d", "%m-%d-%Y", "%m/%d/%y"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    if re.fullmatch(r"\d{4}", text):
        return datetime(int(text), 1, 1)
    # Last resort: grab the first 4-digit year.
    m = re.search(r"(19|20)\d{2}", text)
    if m:
        return datetime(int(m.group(0)), 1, 1)
    return None


def years_between(start_value: str | None, end_value: str | None = None) -> Optional[int]:
    start = parse_yearish(start_value)
    end = parse_yearish(end_value) if end_value else datetime.utcnow()
    if start is None or end is None:
        return None
    years = end.year - start.year
    if (end.month, end.day) < (start.month, start.day):
        years -= 1
    return years


def offense_category_from_text(text: str) -> str:
    n = _norm(text)
    if "assault" in n:
        return "assault"
    if "burglary" in n:
        return "property"
    if "trespass" in n:
        return "property"
    if "theft" in n or "robbery" in n:
        return "property"
    if "drug" in n or "controlled substance" in n or "marijuana" in n:
        return "drug"
    if "dw i" in n or "dwi" in n or "intox" in n:
        return "intoxication"
    return "other"
