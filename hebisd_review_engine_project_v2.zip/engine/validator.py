from __future__ import annotations

from typing import Any, Dict, List


def validate_case_result(case_result: Dict[str, Any]) -> Dict[str, Any]:
    errors: List[str] = []
    warnings: List[str] = []

    if not case_result.get("applicant_name"):
        errors.append("Missing applicant name.")
    if not case_result.get("position"):
        errors.append("Missing position.")
    offenses = case_result.get("offenses") or []
    if not offenses:
        errors.append("No offenses provided.")

    for idx, offense in enumerate(offenses, start=1):
        if not offense.get("offense_text"):
            errors.append(f"Offense {idx} is missing offense_text.")
        if not offense.get("classification"):
            warnings.append(f"Offense {idx} has no classification.")
        if not offense.get("severity"):
            warnings.append(f"Offense {idx} has no severity.")
        path = offense.get("path") or []
        if not path:
            errors.append(f"Offense {idx} has no path.")
            continue
        questions = [step.get("question") for step in path if isinstance(step, dict) and "question" in step]
        if 1 not in questions:
            errors.append(f"Offense {idx} does not start at question 1.")
        if offense.get("terminal") not in {"ELIGIBLE", "CRC_REVIEW", "INELIGIBLE"}:
            warnings.append(f"Offense {idx} terminal is unusual: {offense.get('terminal')!r}")

    passed = not errors
    return {"passed": passed, "errors": errors, "warnings": warnings}
