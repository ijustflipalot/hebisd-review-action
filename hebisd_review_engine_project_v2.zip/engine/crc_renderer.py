from __future__ import annotations

from pathlib import Path
from typing import Dict, Any

try:
    from docx import Document
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "crc_renderer.py requires python-docx. Install with: pip install python-docx"
    ) from exc


def render_crc_docx(template_docx: str | Path, output_docx: str | Path, crc_data: Dict[str, Any]) -> Path:
    template_path = Path(template_docx)
    output_path = Path(output_docx)
    if not template_path.exists():
        raise FileNotFoundError(f"CRC template not found: {template_path}")

    doc = Document(template_path)

    replacements = {
        "{{DATE_OF_CRC_REVIEW}}": crc_data.get("date_of_crc_review", ""),
        "{{APPLICANT_NAME}}": crc_data.get("applicant_name", ""),
        "{{DATE_OF_APPLICATION}}": crc_data.get("date_of_application", ""),
        "{{DATE_OF_HIRE}}": crc_data.get("date_of_hire", ""),
        "{{POSITION_RECOMMENDED}}": crc_data.get("position", ""),
        "{{DIVISION}}": crc_data.get("division", ""),
        "{{DECISION_TEXT}}": crc_data.get("decision_text", ""),
        "{{ADDITIONAL_INFORMATION}}": crc_data.get("additional_information", ""),
    }

    for paragraph in doc.paragraphs:
        for needle, value in replacements.items():
            if needle in paragraph.text:
                # Simple paragraph-level replacement. Good enough for a starter template.
                for run in paragraph.runs:
                    if needle in run.text:
                        run.text = run.text.replace(needle, str(value))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output_path)
    return output_path
