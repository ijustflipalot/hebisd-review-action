from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from .render_utils import Stamp, merge_pdfs, render_stamps_from_dicts, stamp_pdf


DEFAULT_CHECKBOX_SIZE = 11.0


def _default_rect_for_question(question: int, offset_y: float = 0.0) -> tuple[float, float, float, float]:
    # Placeholder coordinates suitable only for starter use.
    # Replace with your actual template's coordinates.
    x0 = 40.0
    y0 = 40.0 + (question * 12.0) + offset_y
    return (x0, y0, x0 + DEFAULT_CHECKBOX_SIZE, y0 + DEFAULT_CHECKBOX_SIZE)


def build_render_stamps(case_result: Dict[str, Any], *, color_cycle: Optional[List[tuple[float, float, float]]] = None) -> List[Dict[str, Any]]:
    if color_cycle is None:
        color_cycle = [
            (0.85, 0.0, 0.0),
            (0.0, 0.5, 0.0),
            (0.0, 0.2, 0.8),
            (0.6, 0.0, 0.6),
        ]

    stamps: List[Dict[str, Any]] = []
    header = case_result.get("case_meta", {})
    stamps.extend(
        [
            {"page": 0, "kind": "text", "rect": (120, 35, 500, 50), "text": case_result.get("applicant_name", ""), "font_size": 11},
            {"page": 0, "kind": "text", "rect": (120, 50, 500, 65), "text": case_result.get("position", ""), "font_size": 11},
        ]
    )

    offenses = case_result.get("offenses", [])
    for idx, offense in enumerate(offenses):
        color = color_cycle[idx % len(color_cycle)]
        for step in offense.get("path", []):
            q = step.get("question")
            if q is None:
                continue
            # Placeholder mapping: use a deterministic pseudo-layout.
            rect = _default_rect_for_question(int(q), offset_y=idx * 16.0)
            stamps.append({"page": 0, "kind": "x", "rect": rect, "color": color})
        # Offense annotation / legend line
        legend_text = f'{offense.get("date","")} | {offense.get("offense_text","")} | {offense.get("classification","")} | {offense.get("severity","")}'
        stamps.append({"page": 0, "kind": "text", "rect": (40, 560 + idx * 14, 550, 575 + idx * 14), "text": legend_text, "font_size": 8})

    return stamps


def render_case_pdfs(
    case_result: Dict[str, Any],
    *,
    decision_tree_template_pdf: str | Path,
    crc_template_pdf: str | Path | None = None,
    output_dir: str | Path = "output",
) -> Dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    decision_tree_template_pdf = Path(decision_tree_template_pdf)
    if not decision_tree_template_pdf.exists():
        raise FileNotFoundError(f"Decision tree template not found: {decision_tree_template_pdf}")

    render_ready = build_render_stamps(case_result)
    stamps_path = output_dir / "render_ready.json"
    stamps_path.write_text(json.dumps(render_ready, indent=2), encoding="utf-8")

    decision_tree_out = output_dir / "decision_tree_completed.pdf"
    stamp_pdf(decision_tree_template_pdf, decision_tree_out, [Stamp(**s) for s in render_ready], flatten=True)

    outputs = {"decision_tree_pdf": str(decision_tree_out), "render_ready_json": str(stamps_path)}

    if case_result.get("crc_required") and crc_template_pdf:
        crc_template_pdf = Path(crc_template_pdf)
        if crc_template_pdf.suffix.lower() == ".docx":
            # The starter engine keeps the CRC as DOCX by default.
            from .crc_renderer import render_crc_docx
            crc_out = output_dir / "crc_review_committee_disposition_filled.docx"
            render_crc_docx(crc_template_pdf, crc_out, {
                "applicant_name": case_result.get("applicant_name", ""),
                "position": case_result.get("position", ""),
                "date_of_crc_review": case_result.get("case_meta", {}).get("crc_review_date", ""),
            })
            outputs["crc_docx"] = str(crc_out)
        elif crc_template_pdf.suffix.lower() == ".pdf":
            # If you provide a PDF CRC template, you can add PDF stamping here later.
            outputs["crc_pdf_template"] = str(crc_template_pdf)

    return outputs
