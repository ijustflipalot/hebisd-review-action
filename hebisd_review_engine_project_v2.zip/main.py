from __future__ import annotations

import json
from pathlib import Path

import typer
from rich import print as rprint

from hebisd_review_engine import load_rules_workbook, process_case, process_and_render

app = typer.Typer(add_completion=False, help="HEB ISD review engine starter CLI.")


@app.command()
def analyze(
    case: Path = typer.Option(..., "--case", exists=True, readable=True, help="Path to case JSON."),
    rules: Path = typer.Option(Path("rules/HEB_ISD_Rules_Workbook.xlsx"), "--rules", exists=True, readable=True, help="Path to rules workbook."),
    out: Path = typer.Option(Path("output"), "--out", help="Output directory."),
):
    case_data = json.loads(case.read_text(encoding="utf-8"))
    catalog = load_rules_workbook(rules)
    result = process_case(case_data, catalog)
    out.mkdir(parents=True, exist_ok=True)
    (out / "analysis.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    rprint({"validation": result["validation"], "crc_required": result["crc_required"]})


@app.command()
def render(
    case: Path = typer.Option(..., "--case", exists=True, readable=True, help="Path to case JSON."),
    rules: Path = typer.Option(Path("rules/HEB_ISD_Rules_Workbook.xlsx"), "--rules", exists=True, readable=True, help="Path to rules workbook."),
    decision_tree_template_pdf: Path = typer.Option(..., "--decision-tree-template", exists=True, readable=True),
    crc_template: Path = typer.Option(None, "--crc-template", exists=False, readable=True),
    out: Path = typer.Option(Path("output"), "--out", help="Output directory."),
):
    case_data = json.loads(case.read_text(encoding="utf-8"))
    catalog = load_rules_workbook(rules)
    result = process_and_render(
        case_data,
        catalog,
        decision_tree_template_pdf=decision_tree_template_pdf,
        crc_template_pdf=crc_template,
        output_dir=out,
    )
    out.mkdir(parents=True, exist_ok=True)
    (out / "full_result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    rprint(result.get("outputs", result["validation"]))


if __name__ == "__main__":
    app()
