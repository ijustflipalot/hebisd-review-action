from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Tuple

from engine import ApplicantCase, CrimeEvent, build_case_paths, load_rules_workbook, render_case_pdfs, validate_case_result


def _coerce_case(case_data: Dict[str, Any]) -> ApplicantCase:
    events_data = case_data.get("events") or case_data.get("offenses") or []
    events = []
    for item in events_data:
        events.append(
            CrimeEvent(
                date=str(item.get("date", "")),
                offense_text=str(item.get("offense_text") or item.get("offense") or item.get("text") or ""),
                disposition=str(item.get("disposition", "arrest")),
                treat_as_conviction=bool(item.get("treat_as_conviction", True)),
                notes=str(item.get("notes", "")),
            )
        )
    return ApplicantCase(
        applicant_name=str(case_data.get("applicant_name", "")),
        position=str(case_data.get("position", "")),
        arrest_date=case_data.get("arrest_date"),
        application_date=case_data.get("application_date"),
        events=events,
        extra={k: v for k, v in case_data.items() if k not in {"applicant_name", "position", "arrest_date", "application_date", "events", "offenses"}},
    )


def process_case(case_data: Dict[str, Any], rules) -> Dict[str, Any]:
    case = _coerce_case(case_data)
    raw = build_case_paths(case, rules)
    validation = validate_case_result(raw)

    result = {
        "applicant_name": raw["applicant_name"],
        "position": raw["position"],
        "case_meta": raw["case_meta"],
        "offenses": raw["offenses"],
        "crc_required": raw["crc_required"],
        "validation": validation,
        "render_ready": {
            "stamps": [],
            "template_notes": "Populate actual checkbox rectangles in pdf_renderer.py before production use.",
        },
    }
    return result


def process_case_file(case_path: str | Path, rules_path: str | Path) -> Dict[str, Any]:
    case_data = json.loads(Path(case_path).read_text(encoding="utf-8"))
    rules = load_rules_workbook(rules_path)
    return process_case(case_data, rules)


def process_and_render(
    case_data: Dict[str, Any],
    rules,
    *,
    decision_tree_template_pdf: str | Path,
    crc_template_pdf: str | Path | None = None,
    output_dir: str | Path = "output",
) -> Dict[str, Any]:
    result = process_case(case_data, rules)
    if not result["validation"]["passed"]:
        return result

    outputs = render_case_pdfs(
        result,
        decision_tree_template_pdf=decision_tree_template_pdf,
        crc_template_pdf=crc_template_pdf,
        output_dir=output_dir,
    )
    result["outputs"] = outputs
    return result


__all__ = [
    "load_rules_workbook",
    "process_case",
    "process_case_file",
    "process_and_render",
]
