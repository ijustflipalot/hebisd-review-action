Place the actual HEB Decision Tree PDF template here as `DecisionTreeTemplate.pdf`.

If you want to use the CRC DOCX renderer, place the template DOCX here:
`CRC Review Committee Disposition form.docx`

The starter engine does not ship the original HEB templates.
